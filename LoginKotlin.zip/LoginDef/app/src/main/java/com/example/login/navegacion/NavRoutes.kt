package com.example.login.navegacion

import androidx.navigation.NamedNavArgument
import androidx.navigation.NavType
import androidx.navigation.navArgument
import dagger.hilt.android.AndroidEntryPoint


sealed class NavRoutes(val route: String ){

    object Factura : NavRoutes(route = "Pantalla3")
    object Menu : NavRoutes(route = "Pantalla2")


    object homeMenu : NavRoutes(route = "Pantalla1/{email}/{pass}") {
        fun createRoute(email:String, pass:String):String {
            return "Pantalla1/$email/$pass"
        }
    }
    object irREgistr : NavRoutes(route = "PantallaRegist")


    object home : NavRoutes(route = "LoginScreen/{email}/{pass}") {
        fun createRouteNueva(email:String, pass:String):String {
            return "LoginScreen/$email/$pass"
        }
    }
}
