package com.example.login

import androidx.annotation.StringRes

data class RegisterState(
    val sucessRegister: Boolean = false,
    val displayProgressBar: Boolean = false,
    @StringRes val errorMessages: Int? = null
)
