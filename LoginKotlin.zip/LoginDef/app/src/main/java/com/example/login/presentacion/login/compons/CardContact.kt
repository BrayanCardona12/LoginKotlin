package com.example.login.presentacion.login.compons

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.login.R

@Composable
fun ContactoCard(
    modifier: Modifier = Modifier,
    Imagen: Int,
    textNom: String,
    numContact: Int,
    textEmail : String
){
    Spacer(modifier = Modifier.height(10.dp))
    Row(modifier = Modifier
        .width(260.dp)
        .background(Color.LightGray), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Image(modifier = Modifier.width(130.dp),painter = painterResource(id = Imagen), contentDescription = textNom)
        Column(modifier = Modifier.padding( 2.dp ),  verticalArrangement = Arrangement.Center) {
            Text(text = textNom)
            Text(text = "$numContact")
            Text(text = textEmail)
        }
    }
    Spacer(modifier = Modifier.height(10.dp))
}

@Preview()
@Composable
fun Sd(){
    ContactoCard(modifier = Modifier, R.drawable.arepa,"pepe", 232334234, "braya@gmail.com")
}