package com.example.login.navegacion


import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.login.LoginViewModel
import com.example.login.RegisterViewModel
import com.example.login.presentacion.login.LoginScreen
import com.example.login.presentacion.login.registro.PantallaRegist
import com.example.login.screensmenu.Pantalla1
import com.example.login.screensmenu.Pantalla2
import com.example.login.screensmenu.Pantalla3
import dagger.hilt.android.AndroidEntryPoint


@Composable
fun Navegacioon() {

    var contr = rememberNavController()
    NavHost(navController = contr, startDestination = NavRoutes.home.route) {

        val viewModel = LoginViewModel()


        composable(route = NavRoutes.home.route) {

            if (viewModel.state.value.successLogin) {
                LaunchedEffect(key1 = Unit) {

                    contr.navigate(NavRoutes.homeMenu
                        .createRoute(viewModel.state.value.email,viewModel.state.value.pass )) {
                        popUpTo(NavRoutes.home.route) {
                            inclusive = true
                        }
                    }
                }
            } else {
                LoginScreen(contr,
                    state = viewModel.state.value,
                    onLogin = viewModel::login,
                    onDissmissDialog = viewModel::hideErrorDialog,
                    onNavigateToRegister = {
                        contr.navigate(NavRoutes.irREgistr.route)
                    })
            }
        }



        composable(route = NavRoutes.homeMenu.route, arguments = listOf(
            navArgument("email") { type = NavType.StringType },
            navArgument("pass") { type = NavType.StringType }
        )) {
            Pantalla1(
                contr,
                email = it.arguments?.getString("email") ?: "",
                pass = it.arguments?.getString("pass") ?: ""
            )
        }


        val viewModel2 = RegisterViewModel()
        composable(NavRoutes.irREgistr.route) {
            PantallaRegist(
                contr,
                state = viewModel2.state.value,
                onRegister = viewModel2::rregister,
                onBack = { contr.popBackStack() },
                onDismissDialog = viewModel2::hideErrorDialog

            )
        }


        composable(route = NavRoutes.Menu.route) { Pantalla2(contr) }
        composable(route = NavRoutes.Factura.route) { Pantalla3(contr) }

    } // fin del NavHost
} // fin del navigation

//fun NavGraphBuilder.LoginScreen(navController: NavController) {
//    composable(route = NavRoutes.home.route) {
//        LoginScreen(navController)
//    }
//}