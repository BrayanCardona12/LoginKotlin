package com.example.login.presentacion.login.registro

import android.widget.Space
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.ClickableText
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.login.RegisterState
import com.example.login.navegacion.NavRoutes
import com.example.login.presentacion.login.compons.BotonRounded
import com.example.login.presentacion.login.compons.EventDialog
import com.example.login.presentacion.login.compons.SocialBoton
import com.example.login.presentacion.login.compons.TransTextFile

@Composable
fun PantallaRegist(
    navController: NavController,
    state: RegisterState,
    onRegister : (String, String,String,String,String) -> Unit,
    onBack : () -> Unit,
    onDismissDialog: () -> Unit
    ) {
    val nameValue = remember { mutableStateOf("") }
    val emailValue = remember { mutableStateOf("") }
    val phoneValue = remember { mutableStateOf("") }
    val passValue = remember { mutableStateOf("") }
    val confirmPassValue = remember { mutableStateOf("") }

    var passwordVisi by remember { mutableStateOf(false) }
    var confirmPassVisi by remember { mutableStateOf(false) }

    val focusManeger = LocalFocusManager.current
    Box(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onBack() }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Regresar",
                        tint = MaterialTheme.colors.primary,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.home.route) }
                    )
                }
                Text(
                    text = "Crear una Cuenta",
                    style = MaterialTheme.typography.h6.copy(color = MaterialTheme.colors.primary)
                )
            } // Fin del row que esta dentro ded la columna principal

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TransTextFile(
                    textFieldValue = nameValue,
                    textLabel = "Nombre",
                    keyboardType = KeyboardType.Text,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManeger.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )  // Texto Nombre
                TransTextFile(
                    textFieldValue = emailValue,
                    textLabel = "Correo",
                    keyboardType = KeyboardType.Email,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManeger.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )  // Texto correo
                TransTextFile(
                    textFieldValue = phoneValue,
                    textLabel = "Telefono",
                    maxChar = 10,
                    keyboardType = KeyboardType.Phone,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManeger.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next
                )// Texto telefono
                TransTextFile(
                    textFieldValue = passValue,
                    textLabel = "Contraseña",
                    keyboardType = KeyboardType.Password,
                    keyboardActions = KeyboardActions(
                        onNext = {
                            focusManeger.moveFocus(FocusDirection.Down)
                        }
                    ),
                    imeAction = ImeAction.Next,
                    trailingIcon = {
                        IconButton(
                            onClick = { passwordVisi = !passwordVisi }) {
                            Icon(
                                imageVector = if (passwordVisi) {
                                    Icons.Default.Visibility
                                } else {
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Toggle"
                            )
                        }
                    }, // fin del trailingIcon
                    visualTransformation = if (passwordVisi) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    }

                )  // Texto clave
                TransTextFile(textFieldValue = confirmPassValue,
                    textLabel = "Confirmar Constraseña",
                    keyboardType = KeyboardType.Password,
                    trailingIcon = {
                        IconButton(
                            onClick = { confirmPassVisi = !confirmPassVisi }) {
                            Icon(
                                imageVector = if (confirmPassVisi) {
                                    Icons.Default.Visibility
                                } else {
                                    Icons.Default.VisibilityOff
                                },
                                contentDescription = "Toggle"
                            )
                        }
                    }, visualTransformation = if (confirmPassVisi) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManeger.clearFocus()
                            onRegister(
                               nameValue.value,
                               emailValue.value,
                                phoneValue.value,
                               passValue.value,
                               confirmPassValue.value
                            )
                        }
                    ),
                    imeAction = ImeAction.Done) // Texto confirmar clave
                Spacer(modifier = Modifier.height(16.dp)) // Espacio
                BotonRounded(
                    modifier = Modifier.clickable { navController.navigate(route = NavRoutes.home.route) },
                    text = "Sing Up",
                    displayProgressBar = state.displayProgressBar,
                    onClick = {  onRegister(
                        nameValue.value,
                        emailValue.value,
                        phoneValue.value,
                        passValue.value,
                        confirmPassValue.value
                    )

                    }
                )  // Fin del boton rounded (Sing Up)
                ClickableText(text = buildAnnotatedString {
                    append("Already have Account")
                    withStyle(
                        style = SpanStyle(
                            color = MaterialTheme.colors.primary,
                            fontWeight = FontWeight.Bold
                        )
                    ) {
                        append(" Log In")
                    }
                }, onClick = {
                    onBack()
                }) // Listo un contador

            } // Fin de la columna Interior
            Spacer(modifier = Modifier.height(16.dp))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray
                    ) // Linea Divisora

                    Text(
                        modifier = Modifier.padding(8.dp),
                        text = "OR"
                    ) // Linea OR
                    Divider(
                        modifier = Modifier.width(24.dp),
                        thickness = 1.dp,
                        color = Color.Gray
                    )
                } // Fin de la fila
                Text(
                    modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth(),
                    text = "Login With",
                    style = MaterialTheme.typography.body1.copy(MaterialTheme.colors.primary),
                    textAlign = TextAlign.Center
                )
            } // Fin columna interna
            Spacer(modifier = Modifier.height(16.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                SocialBoton(
                    text = "Login With Facebook",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.onBackground)
                SocialBoton(
                    text = "Login With Gmail",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.secondary)
                SocialBoton(
                    text = "Login With Instragram",
                    onClick = { /*TODO*/ },
                    socialMediaColor = MaterialTheme.colors.error)

            }
        }//Fin de la columna principal

        if(state.errorMessages != null) {
            EventDialog(errorMessage = state.errorMessages,
                onDismiss = onDismissDialog)}
    }// Fin del box principal
}// Fin de la funcion



