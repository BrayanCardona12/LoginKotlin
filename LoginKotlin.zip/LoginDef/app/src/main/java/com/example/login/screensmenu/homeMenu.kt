package com.example.login.screensmenu

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.BottomAppBar
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.login.R
import com.example.login.navegacion.NavRoutes


@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Pantalla1(navController: NavController, email: String, pass:String) {
    Scaffold(
        topBar = {
            TopAppBar(backgroundColor = Color.DarkGray, modifier = Modifier.height(100.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    Image(painter = painterResource(id = R.drawable.rest), contentDescription = "", modifier = Modifier
                        .clip(CircleShape)
                        .border(5.dp, Color.LightGray, CircleShape))
                    Text(text = "Restaurante", style = TextStyle(Color.LightGray, fontWeight = FontWeight.Bold, fontSize = 35.sp))
                    Image(painter = painterResource(id = R.drawable.menu_book), contentDescription = "", modifier = Modifier
                        .size(75.dp).clickable { navController.navigate(route = NavRoutes.Menu.route) })
                }

            }
        },
        bottomBar = {
            BottomAppBar(backgroundColor = Color.DarkGray, modifier = Modifier.height(50.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                    Image(painter = painterResource(id = R.drawable.arrow_back), contentDescription = null, modifier = Modifier.clickable { navController.navigate( NavRoutes.home.route) } )
                    Image(painter = painterResource(id = R.drawable.arrow_forward), contentDescription = null, modifier = Modifier.clickable { navController.navigate( NavRoutes.Menu.route) } )

                }
            }
        }

    ) {
        Contpantalla1(navController, email, pass )
    }


}

@Composable
fun Contpantalla1(navController: NavController, email: String, pass:String) {
    Column(
        modifier = Modifier
            .background(Color.Gray)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        CardsBody(email, pass)

    }

}



@Composable
fun CardsBody(email:String, pass:String){
    Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Image(painter = painterResource(id = R.drawable.persona1) , contentDescription = null,
            modifier = Modifier
                .clip(CircleShape)
                .border(6.dp, Color.DarkGray, CircleShape))

        Text(text = "Cristian Hernandez", style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold))
        Text(text = "C.C: 10.70.45.10.50")
        Text(text = "$email")
        Text(text = "$pass")

    }
}