package com.example.login.screensmenu

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.BottomAppBar
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

import com.example.login.R
import com.example.login.navegacion.NavRoutes
import com.example.login.presentacion.login.compons.ContactoCard

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Pantalla3(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(backgroundColor = Color.DarkGray, modifier = Modifier.height(100.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly) {
                    Image(painter = painterResource(id = R.drawable.rest), contentDescription = "", modifier = Modifier
                        .clip(CircleShape)
                        .border(5.dp, Color.LightGray, CircleShape))
                    Text(text = "Restaurante", style = TextStyle(Color.LightGray, fontWeight = FontWeight.Bold, fontSize = 35.sp))
                    Image(painter = painterResource(id = R.drawable.home), contentDescription = "", modifier = Modifier
                        .size(75.dp)
                        .clickable { navController.navigate(NavRoutes.home.route) })
                }

            }
        },
        bottomBar = {
            BottomAppBar(backgroundColor = Color.DarkGray, modifier = Modifier.height(50.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceEvenly) {
                    Image(painter = painterResource(id = R.drawable.arrow_back), contentDescription = null, modifier = Modifier.clickable { navController.navigate( NavRoutes.Menu.route) } )
                    Image(painter = painterResource(id = R.drawable.arrow_forward), contentDescription = null, modifier = Modifier.clickable { navController.navigate( NavRoutes.home.route) } )

                }
            }
        }
    ) {
        ContPantalla3()
    }
}

@Composable
fun ContPantalla3() {
    LazyColumn(
        modifier = Modifier
            .background(Color.Gray)
            .fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center ) {
                Image(modifier = Modifier
                    .clip(CircleShape)
                    .border(3.dp, Color.LightGray, CircleShape)
                    .size(150.dp),painter = painterResource(id = R.drawable.persona1), contentDescription = null )
                Column() {
                    Text(text = "Cristian Hernandez", style =  TextStyle(fontSize = 23.sp, fontWeight = FontWeight.Bold), modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                    Text(text = "1. Arepa rellena $4.500", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                    Text(text = "2. Arepa rellena $30.000", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                    Text(text = "3. Empanada $2.200", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                    Text(text = "___________________________", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))
                    Text(text = "= $36.700", modifier = Modifier.padding(10.dp, 0.dp, 10.dp, 0.dp ))

                }
            }
            Text(text = "Sugerencias...")
            ContactoCard(Imagen = R.drawable.r1, textNom = "El Portico", numContact = 32428444, textEmail = "portico@gmail.com" )
            ContactoCard(Imagen = R.drawable.r2, textNom = "EatHere", numContact = 32121232, textEmail = "Eat1@gmail.com")
        }
    }
}
