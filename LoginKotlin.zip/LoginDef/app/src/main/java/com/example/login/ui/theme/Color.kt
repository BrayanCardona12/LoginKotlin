package com.example.login.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val Blue500 = Color(0xFF2196f3)
val BLUE800 = Color(0xFF0277BD)
val CYAN500 = Color(0xFF00bcd4)
val CYAN700 = Color(0xff008ba3)
val LIGHTBLUE50 = Color(0xffe1f5fe)
val LIGHTBLUE100 = Color(0xffb3e5fc)
val RED600 = Color(0xffe53935)

val BLUE900 = Color(0xFF2196f3)
val BLUE950 = Color(0xFF002171)
val CYAN900 = Color(0xFF006064)
val CYAN800 = Color(0xff428e92)
val BLUEGREY900 = Color(0xff000a12)
val BLUEGREY800 = Color(0xff263238)